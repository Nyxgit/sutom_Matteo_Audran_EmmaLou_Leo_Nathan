<?php 
// src/Controller/TimerController.php
namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\Session\SessionInterface;

class TimerController extends AbstractController
{
    public function index(SessionInterface $session): Response
    {
        // Enregistrer le timestamp de début dans la session
        $session->set('start_time', time());

        return $this->render('timer/index.html.twig');
    }
}
